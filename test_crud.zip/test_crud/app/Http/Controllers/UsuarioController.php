<?php
  
namespace App\Http\Controllers;
  
use App\Usuario;
use App\Perfiles;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use DB;

class UsuarioController extends Controller
{

  /*  public function __construct()
    {
        $this->PDO = DB::connection()->getPdo();
    }
*/
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {     

      /*  $QUERY = $this->PDO->prepare("SELECT  * FROM usuarios");
        $QUERY->execute();
        $usuarios = $QUERY->fetchAll(\PDO::FETCH_OBJ);*/

        

        $usuarios = Usuario::latest()->paginate(5);

        $perfiles = Perfiles::all();

  
 
     //   dd($phone = Usuario::all());
 
        return view('usuarios.index',compact('usuarios','perfiles'))
            ->with('i', (request()->input('page', 1) - 1) * 5);
    }
   
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('usuarios.create');
    }
  
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request){

        $request->validate([

         /*   'nombre' => "required",   
            'apellido' => 'required',*/
            'estado' => 'required',
            'image' => 'image|mimes:jpeg,png,jpg|max:1048',         
        ]);

        if($request->image){
    
            $imageName = time().'.'.$request->image->extension();
            $request->image->move(public_path('images'), $imageName);

            $request->request->add(['imagen' => $imageName]);

        }
        $usuario = Usuario::create($request->all());

        return $usuario;

    }
   
    /**
     * Display the specified resource.
     *
     * @param  \App\Usuario  $usuario
     * @return \Illuminate\Http\Response
     */
    public function show(Usuario $usuario)
    {
        return view('usuarios.show',compact('usuario'));
    }
   
    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Usuario  $usuario
     * @return \Illuminate\Http\Response
     */
    public function edit(Usuario $usuario)
    {
        return view('usuarios.edit',compact('usuario'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Usuario  $usuario
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Usuario $usuario)
    {
        $request->validate([

             /*  'nombre' =>'required',
            'apellido' => 'required',
         'rut' => ['required',Rule::unique('usuarios')->ignore($usuario->id)],*/
            'estado' =>'required',
            'image' => 'image|mimes:jpeg,png,jpg|max:1048',            
        ]);

        if($request->image){

            $image_path = public_path('images/').$usuario['imagen'];
            if(@getimagesize($image_path)){//Verificamos que la imágen exista
                unlink($image_path);   // Se elimina la imágen             
            }
            $imageName = time().'.'.$request->image->extension(); // Se crea el nombre de la imágen  
            $request->image->move(public_path('images'), $imageName); // se guarda en directorio
            $request->request->add(['imagen' => $imageName]);// Se agrega a array $request el nombre
        }

        $usuario->update($request->all());
  
        return  $usuario;
    }
  
    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Usuario  $usuario
     * @return \Illuminate\Http\Response
     */
    public function destroy(Usuario $usuario)
    {
        $usuario->delete();
  
        return redirect()->route('usuarios.index')
                        ->with('success','Usuario eliminado con éxito');
    }
}