@extends('usuarios.layout')
@section('content')
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Usuario</h2>
            </div>         
            <div class="pull-right">
                <a class="btn btn-primary" href="{{ route('usuarios.index') }}"> Volver</a>
            </div>
        </div>
    </div>
   
    <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Nombre:</strong>
                {{ $usuario->nombre }}
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Apellido:</strong>
                {{ $usuario->apellido }}
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Rut:</strong>
                {{ $usuario->rut }}
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <img src="{{ asset('/images/')}}/{{$usuario->imagen}}" width=" 300">
        </div>

    </div>
@endsection


