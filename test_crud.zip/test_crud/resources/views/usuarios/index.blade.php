@extends('usuarios.layout')
 
@section('content')
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Laravel 8 CRUD Usuarios           <br></h2>
            </div>
            <div class="pull-right">


                <a class="btn btn-success" href="{{ route('usuarios.create') }}"> Crear  usuario</a>
            </div>
        </div>
    </div>
   
    @if ($message = Session::get('success'))
        <div class="alert alert-success">
            <p>{{ $message }}</p>
        </div>
    @endif
                                    
    <table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead><tr>
            <th>N°</th>
            <th>Nombre</th>
            <th>Apellido</th>
            <th>Rut</th>            
            <th width="280px">Accion </th>
        </tr>
        </thead>
        @foreach ($usuarios as $usuario)
        <tbody>
        <tr>
            <td>{{ ++$i }}</td>
            <td>{{ $usuario->nombre }}</td>
            <td>{{ $usuario->apellido }}</td>
            <td>{{ $usuario->rut }}</td>            
            <td>
                <form action="{{ route('usuarios.destroy',$usuario->id) }}" method="POST">
 
                    <a class="btn btn-info carga-iframe" data-toggle="modal" data-target="#myModal" data-iframe="{{ route('usuarios.show',$usuario->id) }}" >Ver</a>
                    
                    <!--a class="btn btn-primary carga-iframe" data-toggle="modal" data-target="#myModal"  data-iframe="{{ route('usuarios.edit',$usuario->id) }}">Editar</a-->
                    <a class="btn btn-primary "   href="{{ route('usuarios.edit',$usuario->id) }}">Editar</a>

                    <div  class="estado_{{ $usuario->estado }} btn"></div>
                    @csrf
                    @method('DELETE')
      
                    <button type="submit" class="btn btn-danger">Eliminar</button>

                </form>
            </td>
        </tr>
        </tbody>
        @endforeach
    </table>
  <!-- Button to Open the Modal -->


<!-- The Modal -->
<div class="modal" id="myModal" aria-labelledby="myLargeModalLabel" >
  <div class="modal-dialog modal-lg" >
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Modal Heading</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
        <div class="embed-responsive embed-responsive-16by9">
          <iframe id="iframe" class="embed-responsive-item" src="" allowfullscreen></iframe>
        </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>
 
    {!! $usuarios->links() !!}
<style type="text/css">
    .estado_1{

        background-color: green;

    }
    .estado_2{

        background-color: red;


    }
  .estado_1::before {
      font-weight: negrita;
      color: navy;
      content: "Activo";
    }

  .estado_2::before {
      font-weight: negrita;
      color: navy;
      content: "Inactivo";
    }
</style>  
@endsection