@extends('usuarios.layout')
   
@section('content')
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Editar Usuario</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-primary" href="{{ route('usuarios.index') }}"> Volver</a>
            </div>
        </div>
    </div>
   
    @if ($errors->any())
        <div class="alert alert-danger">
            <strong>!Ups!</strong> Problemas de envio.<br><br>
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif
  
    <form action="{{ route('usuarios.update',$usuario->id) }}" method="POST"    id="edita_usuario" enctype="multipart/form-data"> 
        @csrf
        @method('PUT')
   
         <div class="row">

 
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <label><strong>Imagen : </strong></label>
                    <input type="file" name="image" class="form-control" id="imagen" onchange="preview()" >
                </div>
            </div>
 
            <img src="{{ asset('/images/')}}/{{$usuario->imagen}}" width="100px" height="100px" id="frame" accept="image/*">

            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Nmbre:</strong>
                    <input type="text" name="nombre" value="{{ $usuario->nombre }}" class="form-control" placeholder="Nombre" id="nombre">
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>apellido:</strong>
                     <input type="text" class="form-control"   name="apellido" placeholder="apellido" id="apellido" value="{{ $usuario->apellido }}">
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>rut:</strong>
                    <input type="text" class="form-control" value="{{ $usuario->rut }}" name="rut" placeholder="rut" id="rut">
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>email:</strong>
                    <input type="text" class="form-control"   name="email" placeholder="email" id="email" value="{{ $usuario->email }}"> 
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>perfil_id: 1 o 2</strong>
                    <input type="text" class="form-control"  name="perfil_id" placeholder="perfil_id" id="perfil_id" value="{{ $usuario->perfil_id }}">
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Estado: 1 o 2</strong>
                    <input type="text" class="form-control"   name="estado" placeholder="estado" id="estado" value="{{ $usuario->estado }} ">
                </div>
            </div>

            <div class="col-xs-12 col-sm-12 col-md-12 text-center">
              <button type="submit" class="btn btn-primary">Enviar</button>
            </div>
        </div>
   
    </form>

<script type="text/javascript">
    function preview() {
     $('#frame').attr('src',URL.createObjectURL(event.target.files[0]));
    }
    $(document).ready(function() {
      

        $('#edita_usuario').submit(function() {




            if(!VerificaRut($("#rut").val())){
                
                alert("rut invalido");

               return false;


            }

            var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
            if(!regex.test($('#email').val())){

                alert("Email invalido");

                return false;

            }


            var nombre = $('#nombre').val();
            var apellido = $('#apellido').val();
            var rut = $('#rut').val();
               var estado = $('#estado').val(); 
               var perfil_id = $('#perfil_id').val();        
               var email = $('#email').val();     
            // Código por si se necesita validar por el lado del cliente
           /* var validar = 1;
            var texto_alert = '';
             
            if(!nombre){
                texto_alert += " Falta nombre ";
                validar = 0;
            }
            if(!apellido){
                texto_alert += " Falta apellido ";
                validar = 0;
            }      
            if(!rut){
                texto_alert += " Falta rut ";
                validar = 0;
            }
            if(!validar){
                alert(texto_alert);
                return
            }*/

            var formData = new FormData(this);

            formData.append('apellido', apellido);
            formData.append('nombre', nombre);
            formData.append('rut', rut); 
            formData.append('estado', estado);
            formData.append('perfil_id', perfil_id); 
            formData.append('email', email); 
            $.ajax({
                type:'POST',
                url: "{{ route('usuarios.update',$usuario->id) }}",
                data: formData,
                cache:false,
                contentType: false,
                processData: false,
                success: (data) => {
                    alert('Usuario editado con éxito');
                    window.location.replace("/usuarios");                    
                },
                error: function(data){
                
                    console.log(data.responseJSON.errors);
                }
            });
        });
 
    });
</script>


@endsection