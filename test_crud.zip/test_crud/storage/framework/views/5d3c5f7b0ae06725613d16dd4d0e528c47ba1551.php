  
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12 margin-tb">
        <div class="pull-left">
            <h2>Agregar usuario</h2>
        </div>
        <div class="pull-right">
            <a class="btn btn-primary" href="<?php echo e(route('usuarios.index')); ?>"> Volver</a>
        </div>
    </div>
</div>
 
<div class="alert alert-danger">
    <strong>!Ups!</strong> Problemas de envio.<br><br>
    <ul id="errores">   

    </ul>
</div>
 
<form method="POST" enctype="multipart/form-data" id="upload_image_form" action="javascript:void(0)" >
                  
    <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Nombre:</strong>
                <input type="text" name="nombre" id="nombre" class="form-control" placeholder="Nombre">
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Apellido:</strong>
                <input type="text" class="form-control"  name="apellido" id="apellido" placeholder="Apellido">
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Rut:</strong>
                <input type="text" class="form-control"   name="rut" id="rut" placeholder="rut">
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>emailemail:</strong>
                <input type="text" class="form-control"   name="email" id="email" placeholder="email">
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Direccion:</strong>
                <input type="text" class="form-control"   name="direccion" id="direccion" placeholder="direccion">
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Perfil:</strong>
                <input type="text" class="form-control"   name="perfil" id="perfil" placeholder="perfil">
            </div>
        </div>
        <!--div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Perfil:</strong>
                <input type="text" class="form-control"   name="perfil" id="perfil" placeholder="perfil">
            </div>
        </div-->
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Estado:</strong>
                <input type="text" class="form-control"   name="estado" id="estado" placeholder="estado">
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <input type="file" name="image" placeholder="Choose image" id="image">                   
            </div>
        </div>     
              
        <div class="col-xs-12 col-sm-12 col-md-12">
            <button type="submit" class="btn btn-primary">Crear usuario</button>
        </div>
    </div>     
</form>
 
<script type="text/javascript">


 function VerificaRut(rut) {

    rut = rut.replace(".", "");
    rut = rut.replace(".", "");
    if (rut.toString().trim() != '' && rut.toString().indexOf('-') > 0) {
        var caracteres = new Array();
        var serie = new Array(2, 3, 4, 5, 6, 7);
        var dig = rut.toString().substr(rut.toString().length - 1, 1);
        rut = rut.toString().substr(0, rut.toString().length - 2);

        for (var i = 0; i < rut.length; i++) {
            caracteres[i] = parseInt(rut.charAt((rut.length - (i + 1))));
        }

        var sumatoria = 0;
        var k = 0;
        var resto = 0;

        for (var j = 0; j < caracteres.length; j++) {
            if (k == 6) {
                k = 0;
            }
            sumatoria += parseInt(caracteres[j]) * parseInt(serie[k]);
            k++;
        }

        resto = sumatoria % 11;
        dv = 11 - resto;

        if (dv == 10) {
            dv = "K";
        }
        else if (dv == 11) {
            dv = 0;
        }

        if (dv.toString().trim().toUpperCase() == dig.toString().trim().toUpperCase())
            return true;
        else
            return false;
    }
    else {
        return false;
    }
}

 
    $(document).ready(function() {

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        $('#upload_image_form').submit(function() {


            if(!VerificaRut($("#rut").val())){
                
                alert("rut invalido");

               return false;


            }

            var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
            if(!regex.test($('#email').val())){

                alert("rut invalido");

                return false;

            }
            var nombre =  $.trim($('#nombre').val());
            var apellido =  $.trim($('#apellido').val());
            var rut =  $.trim($('#rut').val());
            var email =  $.trim($('#email').val());
            var direccion =  $.trim($('#direccion').val());

            var perfil_id =  $.trim($('#perfil').val());
            var estado =  $.trim($('#estado').val());
           // var direccion =  $.trim($('#direccion').val());     

            var formData = new FormData(this);

            formData.append('nombre', nombre) ;
            formData.append('apellido', apellido);
            formData.append('rut', rut);
            formData.append('email', email);
            formData.append('direccion', direccion);

            formData.append('perfil_id', perfil_id);
            formData.append('estado', estado);
    
            $.ajax({
                type:'POST',
                url: "/usuarios",
                data: formData,
                cache:false,
                contentType: false,
                processData: false,
                success: (data) => {
                    alert('Usuario creado con éxito');
                    $(".alert-danger").hide();                    
                    window.location.replace("/usuarios");
                },
                error: function(data){
                    $("#errores").html(""); 
                    var html = '';
                    $.each(data.responseJSON.errors,function(k, v){ 
                        if(k == 'image'){
                            $.each(v,function(k2, v2){                  
                                html += '<li>' + v2 + '</li>';
                            });
                        }else{
                            html += '<li>' + v + '</li>';                           
                        }
                    });
                    $("#errores").append(html);
                    $(".alert-danger").show();
                     
                }
            });
        });

    });
</script>
<style type="text/css">
    .alert-danger{
        display: none;
    }
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('usuarios.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/LARAVEL/test_crud/resources/views/usuarios/create.blade.php ENDPATH**/ ?>