   
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Editar Usuario</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-primary" href="<?php echo e(route('perritos.index')); ?>"> Volver</a>
            </div>
        </div>
    </div>
   
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <strong>!Ups!</strong> Problemas de envio.<br><br>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
  
    <form action="<?php echo e(route('perritos.update',$usuario->id)); ?>" method="POST"    id="edita_perrito" enctype="multipart/form-data"> 
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
   
         <div class="row">

 
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <label><strong>Imagen : </strong></label>
                    <input type="file" name="image" class="form-control" id="imagen" onchange="preview()" >
                </div>
            </div>
 
            <img src="<?php echo e(asset('/images/')); ?>/<?php echo e($usuario->imagen); ?>" width="100px" height="100px" id="frame" accept="image/*">

            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Nmbre:</strong>
                    <input type="text" name="nombre" value="<?php echo e($usuario->nombre); ?>" class="form-control" placeholder="Nombre" id="nombre">
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Color:</strong>
                    <textarea class="form-control" style="height:150px" name="color" placeholder="Color" id="color"><?php echo e($usuario->color); ?></textarea>
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Raza:</strong>
                    <textarea class="form-control" style="height:150px" name="raza" placeholder="Raza" id="raza"><?php echo e($usuario->raza); ?></textarea>
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 text-center">
              <button type="submit" class="btn btn-primary">Enviar</button>
            </div>
        </div>
   
    </form>

<script type="text/javascript">
    function preview() {
     $('#frame').attr('src',URL.createObjectURL(event.target.files[0]));
    }
    $(document).ready(function() {
      

        $('#edita_perrito').submit(function() {

            var nombre = $('#nombre').val();
            var color = $('#color').val();
            var raza = $('#raza').val();
            
            // Código por si se necesita validar por el lado del cliente
           /* var validar = 1;
            var texto_alert = '';
             
            if(!nombre){
                texto_alert += " Falta nombre ";
                validar = 0;
            }
            if(!color){
                texto_alert += " Falta color ";
                validar = 0;
            }      
            if(!raza){
                texto_alert += " Falta raza ";
                validar = 0;
            }
            if(!validar){
                alert(texto_alert);
                return
            }*/

            var formData = new FormData(this);

            formData.append('color', color);
            formData.append('nombre', nombre);
            formData.append('raza', raza); 

            $.ajax({
                type:'POST',
                url: "<?php echo e(route('perritos.update',$usuario->id)); ?>",
                data: formData,
                cache:false,
                contentType: false,
                processData: false,
                success: (data) => {
                    alert('Usuario editado con éxito');
                    window.location.replace("/perritos");                    
                },
                error: function(data){
                
                    console.log(data.responseJSON.errors);
                }
            });
        });
 
    });
</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('perritos.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/LARAVEL/crud-perritos/resources/views/perritos/edit.blade.php ENDPATH**/ ?>