   
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Editar Usuario</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-primary" href="<?php echo e(route('usuarios.index')); ?>"> Volver</a>
            </div>
        </div>
    </div>
   
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <strong>!Ups!</strong> Problemas de envio.<br><br>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
  
    <form action="<?php echo e(route('usuarios.update',$usuario->id)); ?>" method="POST"    id="edita_usuario" enctype="multipart/form-data"> 
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
   
         <div class="row">

 
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <label><strong>Imagen : </strong></label>
                    <input type="file" name="image" class="form-control" id="imagen" onchange="preview()" >
                </div>
            </div>
 
            <img src="<?php echo e(asset('/images/')); ?>/<?php echo e($usuario->imagen); ?>" width="100px" height="100px" id="frame" accept="image/*">

            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Nmbre:</strong>
                    <input type="text" name="nombre" value="<?php echo e($usuario->nombre); ?>" class="form-control" placeholder="Nombre" id="nombre">
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>apellido:</strong>
                     <input type="text" class="form-control"   name="apellido" placeholder="apellido" id="apellido" value="<?php echo e($usuario->apellido); ?>">
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>rut:</strong>
                    <input type="text" class="form-control" value="<?php echo e($usuario->rut); ?>" name="rut" placeholder="rut" id="rut">
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>email:</strong>
                    <input type="text" class="form-control"   name="email" placeholder="email" id="email" value="<?php echo e($usuario->email); ?>"> 
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>perfil_id: 1 o 2</strong>
                    <input type="text" class="form-control"  name="perfil_id" placeholder="perfil_id" id="perfil_id" value="<?php echo e($usuario->perfil_id); ?>">
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Estado: 1 o 2</strong>
                    <input type="text" class="form-control"   name="estado" placeholder="estado" id="estado" value="<?php echo e($usuario->estado); ?> ">
                </div>
            </div>

            <div class="col-xs-12 col-sm-12 col-md-12 text-center">
              <button type="submit" class="btn btn-primary">Enviar</button>
            </div>
        </div>
   
    </form>

<script type="text/javascript">
    function preview() {
     $('#frame').attr('src',URL.createObjectURL(event.target.files[0]));
    }
    $(document).ready(function() {
      

        $('#edita_usuario').submit(function() {




            if(!VerificaRut($("#rut").val())){
                
                alert("rut invalido");

               return false;


            }

            var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
            if(!regex.test($('#email').val())){

                alert("Email invalido");

                return false;

            }


            var nombre = $('#nombre').val();
            var apellido = $('#apellido').val();
            var rut = $('#rut').val();
               var estado = $('#estado').val(); 
               var perfil_id = $('#perfil_id').val();        
               var email = $('#email').val();     
            // Código por si se necesita validar por el lado del cliente
           /* var validar = 1;
            var texto_alert = '';
             
            if(!nombre){
                texto_alert += " Falta nombre ";
                validar = 0;
            }
            if(!apellido){
                texto_alert += " Falta apellido ";
                validar = 0;
            }      
            if(!rut){
                texto_alert += " Falta rut ";
                validar = 0;
            }
            if(!validar){
                alert(texto_alert);
                return
            }*/

            var formData = new FormData(this);

            formData.append('apellido', apellido);
            formData.append('nombre', nombre);
            formData.append('rut', rut); 
            formData.append('estado', estado);
            formData.append('perfil_id', perfil_id); 
            formData.append('email', email); 
            $.ajax({
                type:'POST',
                url: "<?php echo e(route('usuarios.update',$usuario->id)); ?>",
                data: formData,
                cache:false,
                contentType: false,
                processData: false,
                success: (data) => {
                    alert('Usuario editado con éxito');
                    window.location.replace("/usuarios");                    
                },
                error: function(data){
                
                    console.log(data.responseJSON.errors);
                }
            });
        });
 
    });
</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('usuarios.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/LARAVEL/test_crud/resources/views/usuarios/edit.blade.php ENDPATH**/ ?>